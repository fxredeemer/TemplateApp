﻿using System.Windows.Controls;

namespace $safeprojectname$.Views
{
    public partial class Page2View : UserControl
    {
        public Page2View()
        {
            InitializeComponent();
        }
    }
}
