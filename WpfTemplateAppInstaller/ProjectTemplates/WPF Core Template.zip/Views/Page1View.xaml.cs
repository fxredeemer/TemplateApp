﻿using System.Windows.Controls;

namespace $safeprojectname$.Views
{
    public partial class Page1View : UserControl
    {
        public Page1View()
        {
            InitializeComponent();
        }
    }
}
