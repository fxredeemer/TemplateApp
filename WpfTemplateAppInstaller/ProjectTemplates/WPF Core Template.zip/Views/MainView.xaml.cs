﻿using AdonisUI.Controls;

namespace $safeprojectname$.Views
{
    public partial class MainView : AdonisWindow
    {
        public MainView()
        {
            InitializeComponent();
        }
    }
}
