﻿namespace $safeprojectname$.ViewModels
{
    internal interface IPageViewModel
    {
        string Title { get; }
    }
}
