﻿using Caliburn.Micro;
using $safeprojectname$.XHome;
using $safeprojectname$.XInfo;
using System.Threading;
using System.Windows;
using ILog = log4net.ILog;

namespace $safeprojectname$
{
    public class ShellViewModel : Conductor<object>
    {
        private Visibility menuCloseIsVisible;
        private Visibility menuOpenIsVisible;
        private readonly ILog logger;
        private readonly IHomeViewModel homeViewModel;
        private readonly IInfoViewModel infoViewModel;
        private readonly CancellationTokenSource cancellationTokenSource;

        public ShellViewModel(
            ILog logger,
            IHomeViewModel homeViewModel,
            IInfoViewModel infoViewModel, 
            CancellationTokenSource cancellationTokenSource)
        {
            this.logger = logger;
            this.homeViewModel = homeViewModel;
            this.infoViewModel = infoViewModel;
            this.cancellationTokenSource = cancellationTokenSource;
            MenuOpenIsVisible = Visibility.Collapsed;
            Home();
        }

        public Visibility MenuOpenIsVisible
        {
            get => menuOpenIsVisible;
            set
            {
                menuOpenIsVisible = value;
                NotifyOfPropertyChange(() => MenuOpenIsVisible);
            }
        }

        public Visibility MenuCloseIsVisible
        {
            get => menuCloseIsVisible;
            set
            {
                menuCloseIsVisible = value;
                NotifyOfPropertyChange(() => MenuCloseIsVisible);
            }
        }

        public void MenuOpen()
        {
            MenuOpenIsVisible = Visibility.Collapsed;
            MenuCloseIsVisible = Visibility.Visible;
        }

        public void MenuClose()
        {
            MenuOpenIsVisible = Visibility.Visible;
            MenuCloseIsVisible = Visibility.Collapsed;
        }

        public void Close()
        {
            cancellationTokenSource.Cancel();
            Application.Current.Shutdown();
        }

        public async void Home()
        {
            await ActivateItemAsync(homeViewModel, cancellationTokenSource.Token);
            logger.Info("Button: " + nameof(Home));
        }

        public async void Info()
        {
            await ActivateItemAsync(infoViewModel, cancellationTokenSource.Token);
            logger.Info("Button: " + nameof(Info));
        }
    }
}