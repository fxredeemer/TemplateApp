﻿using System.Windows.Controls;

namespace $safeprojectname$.XHome
{
    /// <summary>
    ///     Interaktionslogik für HomeView.xaml
    /// </summary>
    public partial class HomeView : UserControl
    {
        public HomeView()
        {
            InitializeComponent();
        }
    }
}