﻿using Caliburn.Micro;

namespace $safeprojectname$.XHome
{
    public interface IHomeViewModel : IScreen
    {

    }

    public class HomeViewModel : Screen, IHomeViewModel
    {
    }
}