﻿using System.Deployment.Application;
using System.Reflection;
using Caliburn.Micro;

namespace $safeprojectname$.XInfo
{
    public interface IInfoViewModel : IScreen
    {

    }

    public class InfoViewModel : Screen, IInfoViewModel
    {
        public InfoViewModel()
        {
            SoftwareVersion = GetSoftwareVersion;
        }

        public string SoftwareVersion { get; set; }

        private string GetSoftwareVersion
        {
            get
            {
                var version = ApplicationDeployment.IsNetworkDeployed ?
                    ApplicationDeployment.CurrentDeployment.CurrentVersion :
                    Assembly.GetExecutingAssembly().GetName().Version;

                return $"Version: {version.Major}.{version.Minor}.{version.Build}.{version.Revision}";
            }
        }
    }
}