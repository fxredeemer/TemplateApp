﻿using System.Windows.Controls;

namespace $safeprojectname$.XInfo
{
    /// <summary>
    ///     Interaktionslogik für InfoView.xaml
    /// </summary>
    public partial class InfoView : UserControl
    {
        public InfoView()
        {
            InitializeComponent();
        }
    }
}