﻿using Autofac;
using Caliburn.Micro;
using $safeprojectname$.XHome;
using $safeprojectname$.XInfo;
using System;
using System.Collections.Generic;
using System.Windows;
using Autofac.log4net;
using System.Threading;

namespace $safeprojectname$
{
    public class AppBootstrapper : BootstrapperBase
    {
        private static IContainer container;
        private static CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();

        public AppBootstrapper()
        {
            this.Initialize();
        }

        protected override void Configure()
        {
            var builder = new ContainerBuilder();

            builder.RegisterInstance(cancellationTokenSource);
            builder.RegisterType<WindowManager>().AsImplementedInterfaces().SingleInstance();
            builder.RegisterType<EventAggregator>().AsImplementedInterfaces().SingleInstance();
            builder.RegisterType<ShellViewModel>();
            builder.RegisterType<HomeViewModel>().AsImplementedInterfaces();
            builder.RegisterType<InfoViewModel>().AsImplementedInterfaces();

            var loggingModule = new Log4NetModule()
            {
                ConfigFileName = "logger.config",
                ShouldWatchConfiguration = true
            };

            builder.RegisterModule(loggingModule);

            container = builder.Build();
        }

        protected override IEnumerable<object> GetAllInstances(Type service)
        {
            var type = typeof(IEnumerable<>).MakeGenericType(service);
            return container.Resolve(type) as IEnumerable<object>;
        }

        protected override object GetInstance(Type service, string key)
        {
            if (string.IsNullOrWhiteSpace(key))
            {
                if (container.IsRegistered(service))
                {
                    return container.Resolve(service);
                }
            }
            else
            {
                if (container.IsRegisteredWithKey(key, service))
                {
                    return container.ResolveKeyed(key, service);
                }
            }

            const string msgFormat = "Could not locate any instances of contract {0}.";
            var msg = string.Format(msgFormat, key ?? service.Name);
            throw new Exception(msg);
        }

        protected override void BuildUp(object instance)
        {
            container.InjectProperties(instance);
        }

        protected override void OnStartup(object sender, StartupEventArgs e)
        {
            DisplayRootViewFor<ShellViewModel>();
        }
    }
}